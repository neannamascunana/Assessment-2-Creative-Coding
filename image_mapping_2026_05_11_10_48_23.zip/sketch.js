let img;

function preload() {
  img = loadImage('Website_SpeciesPage_FischersLovebird02_Challenges.jpg'); 
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 255, 255);

  beginClip(); 
  
  circle(200, 200, 250); 
  
  endClip(); 

  image(img, 0, 0, 400, 400); 
}
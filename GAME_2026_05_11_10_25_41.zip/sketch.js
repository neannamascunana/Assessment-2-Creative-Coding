var pink = document.getElementById("pink");
var enemy = document.getElementById("enemy");
var counter = 0;

function jump(){
    if(pink.classList != "animate"){
        pink.classList.add("animate");
    }
    setTimeout(function(){
        pink.classList.remove("animate");
    },800);
}

setInterval(function(){
    var pinkTop =
    parseInt(window.getComputedStyle(pink).getPropertyValue("top"));

    var enemyLeft =
    parseInt(window.getComputedStyle(enemy).getPropertyValue("left"));

    if(enemyLeft < 90 && enemyLeft > 40 && pinkTop >= 160){
        enemy.style.animation = "none";
        alert("Game Over");
    }
    counter++;
    document.getElementById("score").innerHTML =
    Math.floor(counter/100);

},10);
var word= "hello World";
var font1;
let fontSize = 48; 
function preload()
{
  font1 = loadFont("font.ttf");
}
function setup () {
  createCanvas(600, 400);
  textFont(font1, 100);
  textAlign(CENTER,CENTER);
  textSize(fontSize);
}
function draw () {
 background(0);
  fill(255);
  background(20);

let x = width / 2;
let y = height / 2;
text(word, x, y);

}

function setup() {
  createCanvas(400, 400);
  background(0, 0, 0);
}

function draw() {
  fill(mouseY, 54, 129, 398);
  ellipse(mouseX, mouseY, 80, 80);
}
function mousePressed()
{
  background();
}
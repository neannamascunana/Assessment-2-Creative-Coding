function setup() {
  createCanvas(600, 400);
  background(255,255,255);

  for (let y= 100; y <= 500; y +=100 ) {
    for (let x = 100; x <= 300; x += 100) {
      if(y==300 && x==200)
        {
          fill(0, 242, 12)
        }
      else fill(255, 0, 98)
      
      circle(y, x, 60);
    }
  }
}
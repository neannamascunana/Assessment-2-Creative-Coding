function setup() {
  createCanvas(400, 300);
}

function draw() {
  background(90, 400, 80);
  fill(109, 39, 349, 438)
  rect(150, 80, 190, 100)
  fill(400)
  rect(150, 90, 60, 50)
  rect(220, 90, 50, 50)
  rect(280, 90, 50, 50)
  fill(100)
  circle(179, 180, 50)
  fill(200)
  circle(179, 180, 40, 40, 80)
  fill(100)
  circle(300, 180, 50, 40, 20, 50)
  fill(200)
  circle(300, 180, 40, 40)
}
  
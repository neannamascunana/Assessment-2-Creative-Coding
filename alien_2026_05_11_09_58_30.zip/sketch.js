function setup() {
  createCanvas(400, 400);
}

function draw() {
   background(37, 34, 82);
  stroke(0);
  fill(0, 255, 68)
  rect( 70, 10, 10, 100);
  fill(0, 255, 68)
  rect( 220, 10, 10, 100);
  fill(0, 255, 68);
  circle(150, 150, 200);
  fill(0)
  circle(90, 150, 80);
  fill(0)
  circle(210, 150, 80);
  fill(255, 255, 255)
  circle(70, 140, 40);
  fill(255, 255, 255)
  circle(190, 140, 40);
  fill(0, 255, 68)
  rect(80, 250, 150)
  fill(255, 255, 255)
  str(70, 240, 255);
  fill(255, 255, 255)
  circle(290, 250, 10);
  fill(255, 255, 255)
  circle(370, 150, 10);
  fill(255, 255, 255)
  circle(350, 350, 10);
  fill(255, 255, 255)
  circle(300, 50, 10);
  fill(255, 255, 255)
  circle(190, 30, 10);
  fill(255, 255, 255)
  circle(90, 50, 10);
  fill(255, 255, 255)
  circle(10, 130, 10);
  fill(255, 255, 255)
  circle(50, 250, 10);
  fill(255, 255, 255)
  circle(0, 350, 10);
}
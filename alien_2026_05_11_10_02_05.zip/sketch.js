let pic;

function preload() {
  pic=loadImage('sky-with-a-beautiful-sunset-a-blue-and-orange-sky-with-soft-clouds-a-sky-background-photo.jpg')
}
function setup(){
  createCanvas(400, 400);
}

function draw() {
  background(220);
  image(pic, 100, 100, 250, 250)
}
let sound, fft;

function preload() {
  sound = loadSound('Fall Asleep in 3 Minutes - Cure For Insomnia to Rain Sounds and Thunderstorm.mp3');
}

function setup() {
  createCanvas(400, 400);
  sound.loop();
  fft = new p5.FFT();
}

function draw() {
  background(255, 10);
  let spectrum = fft.analyze();
  let w = width / spectrum.length;
  
  for (let i = 0; i < spectrum.length; i++) {
    let x = i * w;
    let h = map(spectrum[i], 0, 255, 0, height);
    rect(x, height - h, w, h);
  }
}
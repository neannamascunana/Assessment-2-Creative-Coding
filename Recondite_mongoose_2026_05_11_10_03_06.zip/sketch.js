let table;
function preload() {
  table = loadTable('data2.csv', 'csv', 'header');
}

function setup() {
  createCanvas(400, 300);
  background(255);
  
  let barWidth = 100;
  
  for (let i = 0; i < table.getRowCount(); i++) {
    let module = table.getString(i, 'Module');
    let marks = table.getNum(i, 'Marks');
  
    let x = 30 + i * (barWidth + 20);
    let h = map(marks, 0, 100, 0, height);
    
    fill(245, 114, 66);
    rect(x, height-h, barWidth, h);
    
    fill(0);
    textAlign(CENTER);
    textSize(12);
    text(module, x + barWidth / 2, height - 20);
    text(marks, x + barWidth / 2, height - 50);
  }
}